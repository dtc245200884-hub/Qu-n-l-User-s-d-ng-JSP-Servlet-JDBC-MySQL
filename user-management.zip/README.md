# User Management - JSP / Servlet / JDBC / MySQL

Ứng dụng MVC quản lý User gồm danh sách, thêm, sửa và xóa. Tương thích Java 17, Maven và Tomcat 10.1+.

## 1. Tạo cơ sở dữ liệu
Mở MySQL Workbench và chạy `database/demo.sql`.

## 2. Cấu hình kết nối MySQL
Mở `src/main/java/com/codegym/dao/UserDAO.java`, sửa:
- `jdbcURL`
- `jdbcUsername`
- `jdbcPassword`

Mặc định URL là `jdbc:mysql://localhost:3306/demo?useSSL=false&serverTimezone=UTC`, user là `root`, password là `password`. Hãy thay password cho đúng máy của bạn.

## 3. Build
Mở terminal tại thư mục chứa `pom.xml`, chạy:
```bash
mvn clean package
```
Kết quả: `target/user-management.war`.

## 4. Deploy
Copy WAR vào thư mục `webapps` của Tomcat 10.1+, khởi động Tomcat, sau đó mở:
`http://localhost:8080/user-management/users`

## Cấu trúc
- `model/User.java`: dữ liệu User
- `dao/IUserDAO.java`, `dao/UserDAO.java`: CRUD JDBC
- `controller/UserServlet.java`: điều hướng MVC
- `webapp/user/*.jsp`: giao diện

Lưu ý: đây là bài thực hành dùng JDBC trực tiếp, chưa bao gồm đăng nhập/xác thực người dùng.
