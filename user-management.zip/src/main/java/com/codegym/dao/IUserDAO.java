package com.codegym.dao;

import com.codegym.model.User;
import java.util.List;

/** Khai báo các thao tác CRUD với User. */
public interface IUserDAO {
    void insertUser(User user) throws Exception;
    User selectUser(int id) throws Exception;
    List<User> selectAllUsers() throws Exception;
    boolean deleteUser(int id) throws Exception;
    boolean updateUser(User user) throws Exception;
}
