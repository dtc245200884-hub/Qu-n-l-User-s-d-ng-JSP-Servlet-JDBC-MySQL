<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html lang="vi">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Thêm User</title>
<link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css"></head>
<body><div class="container form-container">
<h1>Thêm User mới</h1>
<form action="${pageContext.request.contextPath}/users?action=create" method="post">
    <div class="form-group"><label for="name">Họ tên</label><input id="name" name="name" maxlength="120" required></div>
    <div class="form-group"><label for="email">Email</label><input id="email" type="email" name="email" maxlength="220" required></div>
    <div class="form-group"><label for="country">Quốc gia</label><input id="country" name="country" maxlength="120"></div>
    <div class="form-actions"><button class="btn btn-save" type="submit">Lưu User</button><a class="btn btn-cancel" href="${pageContext.request.contextPath}/users">Hủy</a></div>
</form></div></body></html>
