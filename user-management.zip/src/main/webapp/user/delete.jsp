<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="vi">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Xóa User</title>
<link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css"></head>
<body><div class="container form-container">
<h1>Xác nhận xóa User</h1>
<p>Bạn có chắc chắn muốn xóa người dùng này không?</p>
<p><strong>ID:</strong> <c:out value="${user.id}"/></p>
<p><strong>Họ tên:</strong> <c:out value="${user.name}"/></p>
<p><strong>Email:</strong> <c:out value="${user.email}"/></p>
<p><strong>Quốc gia:</strong> <c:out value="${user.country}"/></p>
<form action="${pageContext.request.contextPath}/users?action=delete" method="post">
    <input type="hidden" name="id" value="<c:out value='${user.id}'/>">
    <div class="form-actions"><button class="btn btn-delete" type="submit">Xác nhận xóa</button><a class="btn btn-cancel" href="${pageContext.request.contextPath}/users">Hủy</a></div>
</form></div></body></html>
