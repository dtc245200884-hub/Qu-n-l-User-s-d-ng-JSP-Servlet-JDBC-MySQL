<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="vi">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Sửa User</title>
<link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css"></head>
<body><div class="container form-container">
<h1>Cập nhật User</h1>
<form action="${pageContext.request.contextPath}/users?action=edit" method="post">
    <input type="hidden" name="id" value="<c:out value='${user.id}'/>">
    <div class="form-group"><label for="name">Họ tên</label><input id="name" name="name" maxlength="120" value="<c:out value='${user.name}'/>" required></div>
    <div class="form-group"><label for="email">Email</label><input id="email" type="email" name="email" maxlength="220" value="<c:out value='${user.email}'/>" required></div>
    <div class="form-group"><label for="country">Quốc gia</label><input id="country" name="country" maxlength="120" value="<c:out value='${user.country}'/>"></div>
    <div class="form-actions"><button class="btn btn-save" type="submit">Cập nhật</button><a class="btn btn-cancel" href="${pageContext.request.contextPath}/users">Hủy</a></div>
</form></div></body></html>
