<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Quản lý User</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>
<div class="container">
    <h1>Quản lý người dùng</h1>
    <div class="actions">
        <span>Danh sách User trong cơ sở dữ liệu</span>
        <a class="btn btn-add" href="${pageContext.request.contextPath}/users?action=create">+ Thêm User</a>
    </div>
    <table>
        <thead><tr><th>ID</th><th>Họ tên</th><th>Email</th><th>Quốc gia</th><th>Thao tác</th></tr></thead>
        <tbody>
        <c:forEach var="user" items="${requestScope.listUser}">
            <tr>
                <td><c:out value="${user.id}"/></td>
                <td><c:out value="${user.name}"/></td>
                <td><c:out value="${user.email}"/></td>
                <td><c:out value="${user.country}"/></td>
                <td>
                    <a class="btn btn-edit" href="${pageContext.request.contextPath}/users?action=edit&id=${user.id}">Sửa</a>
                    <a class="btn btn-delete" href="${pageContext.request.contextPath}/users?action=delete&id=${user.id}">Xóa</a>
                </td>
            </tr>
        </c:forEach>
        <c:if test="${empty requestScope.listUser}">
            <tr><td colspan="5" class="notice">Chưa có dữ liệu User.</td></tr>
        </c:if>
        </tbody>
    </table>
</div>
</body>
</html>
